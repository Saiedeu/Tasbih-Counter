# Digital Tasbih Counter App

## Overview

This is a Progressive Web Application (PWA) for a digital tasbih counter, designed to help Muslims perform dhikr (remembrance of Allah) using their mobile devices or computers. The app provides a modern, clean interface for counting Islamic prayers and remembrances like Subhanallah, Alhamdulillah, and Allahu Akbar.

## System Architecture

The application follows a simple client-side architecture:

- **Frontend**: Pure HTML, CSS, and JavaScript single-page application
- **Runtime Environment**: Python HTTP server for local development
- **Deployment**: Static file hosting (designed for platforms like InfinityFree or similar)
- **Offline Support**: Service Worker implementation for PWA functionality

## Key Components

### 1. Frontend Architecture
- **Single Page Application**: Built with vanilla HTML, CSS, and JavaScript
- **Responsive Design**: Mobile-first approach with touch-friendly interface
- **Progressive Web App**: Installable on mobile devices with offline capability
- **Multi-language Support**: English and Bengali language options

### 2. PWA Features
- **Service Worker** (`sw.js`): Handles caching and offline functionality
- **Web Manifest** (`manifest.json`): Defines app metadata and installation behavior
- **Offline-first**: Caches critical resources for offline usage

### 3. User Interface Components
- Counter display with large, touch-friendly buttons
- Progress tracking and visual feedback
- Sound effects for user interaction
- Settings panel for customization
- Multiple dhikr presets (Subhanallah, Alhamdulillah, Allahu Akbar)

### 4. SEO and Discoverability
- Comprehensive meta tags for search engines
- Open Graph and Twitter Card support
- JSON-LD structured data
- Google Site Verification ready

## Data Flow

1. **User Interaction**: User taps/clicks the counter button
2. **State Management**: JavaScript updates the counter state in memory
3. **Local Storage**: Counter progress persists across sessions
4. **Visual Feedback**: UI updates immediately to reflect new count
5. **Audio Feedback**: Optional sound plays on each count (if enabled)

## External Dependencies

- **Google Fonts**: Poppins font family for typography
- **Font Awesome**: Icon library for UI elements
- **CDN Resources**: External CSS and font resources cached by service worker

## Deployment Strategy

### Current Setup
- **Development Server**: Python HTTP server on port 5000
- **Production**: Static file hosting (configured for InfinityFree at tasbih-counter.rf.gd)

### Deployment Considerations
- All resources are static files (HTML, CSS, JS, manifest, service worker)
- No backend server required for core functionality
- CDN resources are cached for offline performance
- SEO optimized for search engine indexing

### Performance Optimizations
- Service worker caching for instant loading
- Minimal external dependencies
- Optimized for mobile devices
- Progressive enhancement approach

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 24, 2025. Initial setup

## Technical Notes

- The app uses no database - all state is managed client-side with localStorage
- Service worker implements cache-first strategy for offline functionality
- PWA manifest allows installation as native app on mobile devices
- Responsive design ensures compatibility across all device sizes
- SEO implementation includes comprehensive meta tags and structured data

## Future Enhancement Possibilities

- Add more dhikr presets and customizable prayers
- Implement goal setting and achievement tracking
- Add daily/weekly statistics and analytics
- Include Islamic calendar integration
- Add haptic feedback for supported devices
- Implement cloud sync for cross-device progress tracking